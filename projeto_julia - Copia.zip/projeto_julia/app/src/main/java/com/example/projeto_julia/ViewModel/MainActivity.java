package com.example.projeto_julia.ViewModel;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.projeto_julia.MenuActivity;
import com.example.projeto_julia.R;

public class MainActivity extends AppCompatActivity {
    private Button botao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        botao = findViewById(R.id.btnLogin);

        botao.setOnClickListener( v->
                startActivity(new Intent(this, MenuActivity.class))
        );
    }
}